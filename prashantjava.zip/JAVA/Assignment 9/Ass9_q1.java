import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code = "Ass9_q1" width=250 height=250>
 * </applet>
*/

public  class Ass9_q1 extends Applet implements MouseMotionListener
{
	Label l1,l2,l3,l4;
	public void init()
	{
		Label l1 = new Label("Mouse X");
		l2 = new Label("Mouse X Coordinate");
		l2.addMouseMotionListener(this);
		
		Label l3 = new Label("Mouse Y");
		l4 = new Label("Mouse Y Coordinate");
		l4.addMouseMotionListener(this);

		addMouseMotionListener(this);
		setLayout(new GridLayout(3,2));
		add(l1);
		add(l2);
		add(l3);
		add(l4);
	}
	public void mousePressed(MouseEvent me)
	{

	}
	public void mouseClicked(MouseEvent me)
	{

	}
	public void mouseEntered(MouseEvent me)
	{

	}
	public void mouseExited(MouseEvent me)
	{

	}
	public void mouseReleased(MouseEvent me)
	{

	}
	public void mouseDragged(MouseEvent me)
	{

	}
	public void mouseMoved(MouseEvent me)
	{
		l2.setText(String.valueOf(me.getX()));
		l4.setText(String.valueOf(me.getY()));
	}
}






























/*
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class mouse extends JFrame implements MouseMotionListener
{
	static JLabel l1,l2,l3,l4;
	mouse()
	{}
	public static void main(String args[])
    	{
        	JFrame f = new JFrame("MouseMotionListener");
		f.setSize(600, 400);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel p = new JPanel();
		p.setLayout(new FlowLayout());
		l1 = new JLabel("Mouse X");
 		l2 = new JLabel("Mouse Y");
		l3 = new JLabel("Mouse X coordinate");
		l4 = new JLabel("Mouse Y coordinate");
		mouse m = new mouse();
		f.addMouseMotionListener(m);
		p.setLayout(new GridLayout(3,2));
		p.add(l1);
        	p.add(l3);
		p.add(l2);
        	p.add(l4);
		f.add(p);
        	f.show();
		f.setVisible(true);
	}
	public void mouseDragged(MouseEvent e)
	{}
	public void mouseMoved(MouseEvent e)
    	{
        	l3.setText(String.valueOf(e.getX()));
		l4.setText(String.valueOf(e.getY()));
    	}
}	
*/





