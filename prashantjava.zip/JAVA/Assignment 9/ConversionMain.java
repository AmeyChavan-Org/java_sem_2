import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class ConversionMain extends JFrame implements ActionListener
{
  JLabel BinaryResult, OctalResult, HexResult,label;
  JTextField t1;
  JButton ConvertButton, ExitButton;
  Container container;
JFrame f;
String toBinary(int num)
{
int tmp;
    tmp = num;
  
    String binary = "";
    while(num >= 2)
    {
      binary = num%2 + binary ;
      num = num /2;
    }
    binary = num + binary ;
return binary;	    
}
String toOctal(int num)
{
int tmp;
    tmp = num;
   
    String octal = "";
    while(num >= 8)
    {
      octal = num%8 + octal;
      num = num /8;
    }
    octal = num + octal ;
return octal;
}
String toHex(int num)
{
String[] nums = {"0", "1","2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C","D", "E", "F"};
int tmp;
    tmp = num;
    
    String hexa = "";
    while(num >= 16)
    {
      hexa = nums[num%16] + hexa;
      num = num /16;
    }
    hexa = nums[num] + hexa ;
return hexa;
}
ConversionMain()
  {
    f = new JFrame ("Number Conversion");
      f.setSize (400, 200);
      container = getContentPane();	
      f.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      f.setLayout (new GridLayout (5, 2));
      JLabel decimal = new JLabel ("Decimal");
      t1 = new JTextField (20);
	t1.setEditable(true);
	container.add(t1);
	container.add(label = new JLabel("HI"));	
	t1.addKeyListener(new KeyAdapter()
{
	public void keyPressed(KeyEvent ke)
	{
		String value = t1.getText();
		int l = value.length();
		if(ke.getKeyChar() >= '0' && ke.getKeyChar() <='9' || ke.getKeyChar() == '\b')
		{
			t1.setEditable(true);
			label.setText("");		
		}
		else
		{
			t1.setEditable(false);
			label.setText("Enter only numbers (0-9)");
		}
	}
});	
    
    JLabel Binary = new JLabel ("Binary");
    BinaryResult = new JLabel ("Result in Binary");
    JLabel Octal = new JLabel ("Octal");
    OctalResult = new JLabel ("Result in Octal");
    JLabel Hex = new JLabel ("Hexadecimal");
    HexResult = new JLabel ("Result in Hexadecimal");
    ConvertButton = new JButton ("Convert");
    ConvertButton.addActionListener (this);
    ExitButton = new JButton ("Exit");
    ExitButton.addActionListener (this);
    f.add (decimal);
    f.add (t1);
    f.add (Binary);
    f.add (BinaryResult);
    f.add (Octal);
    f.add (OctalResult);
    f.add (Hex);
    f.add (HexResult);
    f.add (ConvertButton);
    f.add (ExitButton);
    f.setVisible (true);
  }
  public void actionPerformed (ActionEvent ae)
  {
    if (ae.getSource () == ConvertButton)
      {
	String decimal = t1.getText ();
	int d = Integer.valueOf (decimal);
        if(d>=0 && d<=15)
        {
	BinaryResult.setText (toBinary(d));
	OctalResult.setText (toOctal(d));
	HexResult.setText (toHex(d));
      }
    else
    {
    t1.setText("");
     BinaryResult.setText ("");
	OctalResult.setText ("");
	HexResult.setText ("");
      JOptionPane.showMessageDialog(f,"Please Enter value between 0 to 15");
    }
}
    if (ae.getSource () == ExitButton)
      {
	System.exit (0);
      }
  }
  public static void main (String args[])
  {
    new ConversionMain();
  }
}
