import java.awt.*;
import java.applet.*;

public class labels extends Applet
{
	public void init()
	{
		Label l1=new Label("Mouse X");
		Label l2=new Label("MOuse X Coordinate");
		Label l3=new Label("Mouse Y");
		Label l4=new Label("Mouse Y Coordinate");
		
		setLayout(new GridLayout(3,2));
		add(l1);
		add(l2);
		add(l3);
		add(l4);
	}
}
/*<applet code="labels" width=500 height=500>
</applet>*/

