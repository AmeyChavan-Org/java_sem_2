import java.awt.*;
import java.applet.*;

/*<applet code="font" width=500 height=500>
</applet>*/

public class font extends Applet
{
	public void paint(Graphics g)
	{
		String msg="";
		String FontList[];
		int y=20;
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		FontList = ge.getAvailableFontFamilyNames();
		
		for(int i = 0; i<FontList.length; i++)
		{
			g.drawString(FontList[i],10,y);
			y+=20;
		}
	}
}

