import java.io.*;
abstract class Shape//declaration of the abstract class 
{
	abstract void calc_area();//abstract method declaration 
	abstract void calc_volume();
}
class Sphere extends Shape//using concept of inheristance used methods inside shape class  
{
	double radius;
	Sphere(double radius)
	{
		this.radius=radius;
	}
	void calc_area()
	{
		System.out.println("\nArea of Sphere is: "+4*Math.PI*radius*radius);
	}
	void calc_volume()
	{
		System.out.println("Volume of Sphere is: "+((4/3)*Math.PI*radius*radius*radius));
	}
}
class Cone extends Shape//using concept of inheristance used methods inside shape class  
{
	double radius,height;
	Cone(double radius,double height)
	{
		this.radius=radius;
		this.height=height;
	}
	void calc_area()
	{
		System.out.println("\nArea of Cone is: "+Math.PI*radius*(radius+(Math.sqrt((height*height)+(radius*radius)))));
	}
	void calc_volume()
	{
		System.out.println("Volume of Cone is: "+Math.PI*radius*radius*(height/3));
	}
}
class Cylinder extends Shape//using concept of inheristance used methods inside shape class  
{
	double radius,height;
	Cylinder(double radius,double height)
	{
		this.radius=radius;
		this.height=height;
	}
	void calc_area()
	{
		System.out.println("\nArea of Cylinder is: "+((2*Math.PI*radius*height)+(2*Math.PI*radius*radius)));
	}
	void calc_volume()
	{
		System.out.println("Volume of Cylinder is: "+Math.PI*radius*radius*height);
	}
}
class Box extends Shape//using concept of inheristance used methods inside shape class  
{
	double length,breadth,height;
	Box(double length,double breadth,double height)
	{
		this.length=length;
		this.breadth=breadth;
		this.height=height;
	}
	void calc_area()
	{
		System.out.println("\nArea of Box is: "+2*((length*breadth)+(length*height)+(breadth*height)));
	}
	void calc_volume()
	{
		System.out.println("Volume of Box is: "+(length*breadth*height));
	}
}
class ShapeMain
{
	public static void main(String args[])throws IOException
	{

		Shape s;
		double radius,height,breadth,length;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); //input accesept from user throw keyboad using bufferedReader class   


		do{
			System.out.print("\nEnter The Radius Of Sphere:");
			radius=Double.parseDouble(br.readLine());
		}while(radius<=0);
		do{
			System.out.print("\nEnter The Radius Of Cone: ");
			height=Double.parseDouble(br.readLine());
		}while(height<=0);
		do{
			System.out.print("\nEnter Height Of The Cone: ");
			breadth=Double.parseDouble(br.readLine());
		}while(breadth<=0);
		do{
			System.out.print("\nEnter Radius Of The Cylinder: ");
			length=Double.parseDouble(br.readLine());
		}while(length<=0);
		do{
			System.out.print("\nEnter Height Of The Cylinder: ");
			length=Double.parseDouble(br.readLine());
		}while(length<=0);

		do{
			System.out.print("\nEnter Length Of The Box: ");
			length=Double.parseDouble(br.readLine());
		}while(length<=0);
		do{
			System.out.print("\nEnter Breadth Of The Box: ");
			length=Double.parseDouble(br.readLine());
		}while(length<=0);
		do{
			System.out.print("\nEnter Height Of The Box: ");
			length=Double.parseDouble(br.readLine());
		}while(length<=0);

		s=new Sphere(radius);
		s.calc_area();
		s.calc_volume();
		
		s=new Cone(radius,height);
		s.calc_area();
		s.calc_volume();
		
		s=new Cylinder(radius,height);
		s.calc_area();
		s.calc_volume();
		
		s=new Box(length,breadth,height);
		s.calc_area();
		s.calc_volume();
	}//closed main method 
}//closed main class 
