import java.io.*;
class Employee{

	private int id;
	private String name,department;
	private float salary;

	Employee() //Default Constructor
	{
	}

	Employee(int id,String name,String department,float salary) //Parameterized Constructor
	{
		this.id=id;
		this.name=name;
		this.department=department;
		this.salary=salary;
	}
	public void display()//To display employee Details using method overridding 
	{
		System.out.print(id+"\t"+name+"\t"+department+"\t"+salary+"\t");
        }
	float getSalary()
	{
		return this.salary;
	}
}
class Manager extends Employee//using concept of inheristance used methods inside shape class 
{
	private int bonus;
	Manager(int id,String name,String department,float salary,int bonus)//parameterized constructor
	{
		super(id,name,department,salary);
		this.bonus=bonus;
	}
	public void display()//overriding using method overridding 
	{
		super.display();
		System.out.println(bonus+"\t"+(super.getSalary()+bonus));
	}
	float getTotal()
	{
		return super.getSalary()+bonus;
	}
	
}
class ManagerMain
{
	public static void main(String args[]) throws IOException
	{
		int i,j,n,id;
		int bonus=0;
		String name,department;
		float salary;
		BufferedReader br = new BufferedReader (new InputStreamReader (System.in));//input accesept from user throw keyboad using         bufferedReader class 
		do
		{
		System.out.println("How many Employee");
		n = Integer.parseInt(br.readLine());
		}while(n<=0);
		Manager[] m=new Manager[n];
		for(i=0;i<n;i++)
		{
			id=i+1;
			System.out.println("Employee id is:"+id);
			do
			{
				System.out.println("Enter The name of the employee:");
				name = br.readLine();
				if(name.length()==0)
				{
					System.out.println("Invalid Input!");
				}
			}while(name.length()==0);
			
			do
			{
				System.out.println("Enter department of the employee:");
				department = br.readLine();
				if(department.length()==0)
				{
					System.out.println("Invalid Input!");
				}
			}while(department.length()==0);
			
			do
			{
				System.out.println("Enter employee salary");
				salary = Float.parseFloat(br.readLine());
				if(salary<=0)
				{
					System.out.println("Invalid Input!");
				}
			}while(salary<=0);
			do
			{
                                
                                if(bonus>salary)
                                {
                                  System.out.println("Bonus cannot be greater then salary!!");
                                  
                                }
				System.out.println("Enter employee bonus for Salary:"+salary);
				bonus = Integer.parseInt(br.readLine());
				if(bonus<0)
				{
					System.out.println("Invalid Input!");
				}
			}while(bonus<0 || bonus>salary);
                       
			System.out.println("---------------------------------------");
			m[i]=new Manager(id,name,department,salary,bonus);
			 bonus=0;
		}
		
		System.out.println();
		double max=0;
		for(i=0;i<m.length;i++)
		{	
			if(max<m[i].getTotal())
			{
				max=m[i].getTotal();
				
			}
			
		}
		
		
		System.out.println("-----------------**Highest salary details:**-----------------\t");
                System.out.println("ID\tName\tDept\tSalary\tBonus\tSalary");
		for(i=0;i<n;i++)
		{
			if(max==m[i].getTotal())
			{
                          
		          m[i].display();			
			}
		}
	}
}








