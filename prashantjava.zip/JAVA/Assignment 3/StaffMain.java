import java.io.*;
abstract class Staff {
     String name;
     String address;

    public Staff(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public abstract void displayDetails();
}

class FullTimeStaff extends Staff {
     String department;
     double salary;

    public FullTimeStaff(String name, String address, String department, double salary) {
        super(name, address);
        this.department = department;
        this.salary = salary;
    }


    public void displayDetails() {
        System.out.println("************************** FullTimeStaff *************************");
        System.out.println("Employee Name: " + name);
        System.out.println("Employee Address: " + address);
        System.out.println("Employee Department: " + department);
        System.out.println("Employee Salary: " + salary);
	//System.out.println("***************************************************");
    }
}

class PartTimeStaff extends Staff {
     int numberOfHours;
     double ratePerHour;

    public PartTimeStaff(String name, String address, int numberOfHours, double ratePerHour) {
        super(name, address);
        this.numberOfHours = numberOfHours;
        this.ratePerHour = ratePerHour;
    }


    public void displayDetails() {
        System.out.println("******************* PartTimeStaff ************************");
        System.out.println("Employee Name: " + name);
        System.out.println("Employee Address: " + address);
        System.out.println("Number of Hours: " + numberOfHours);
        System.out.println("Rate per Hour: " + ratePerHour);
	//System.out.println("**********************************************");
    }
}



public class StaffMain{
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));



            int choice = 0;
            int n = 0;
            Staff[] staff = null;
        
            do {
                System.out.println("1. FullTimeStaff\n2. PartTimeStaff\n3. Exit");
                System.out.print("Enter your choice: ");
                choice = Integer.parseInt(br.readLine());
        
                switch (choice) {
                    case 1:
                        System.out.print("Enter the number of Full-Time Staff members: ");
                        n = Integer.parseInt(br.readLine());
        
                        while (n <= 0) {
                            System.out.print("Invalid details! Enter the number of Full-Time Staff members: ");
                            n = Integer.parseInt(br.readLine());
                        }
        
                        staff = new Staff[n];
        
                        for (int i = 0; i < n; i++) {
                            System.out.println("Enter details for Full-Time Staff member " + (i + 1) + ":");
        
                            System.out.print("Employee Name: ");
                            String name = br.readLine();
                            while (name.length() == 0) {
                                System.out.print("Name can not be empty! Try again: ");
                                name = br.readLine();
                            }
        
                            System.out.print("Employee Address: ");
                            String address = br.readLine();
                            while (address.length() == 0) {
                                System.out.print("Address can not be empty! Try again: ");
                                address = br.readLine();
                            }
        
                            System.out.print("Employee Department: ");
                            String department = br.readLine();
			    while (department.length() == 0) {
                                System.out.print("Department can not be empty! Try again: ");
                                department = br.readLine();
                            }
        
                            System.out.print("Employee Salary: ");
                            double salary = Double.parseDouble(br.readLine());
        
                            while (salary <= 0) {
                                System.out.print("Invalid salary! Enter Salary: ");
                                salary = Double.parseDouble(br.readLine());
                            }
        
                            staff[i] = new FullTimeStaff(name, address, department, salary);
                        }
                         //display
                        System.out.println("\nFull-Time Staff Details:");
                        for (int i = 0; i < n; i++) {
                            staff[i].displayDetails();
                            System.out.println();
                        }
                        break;
        
                    case 2:
                        System.out.print("Enter the number of Part-Time Staff members: ");
                        n = Integer.parseInt(br.readLine());
        
                        //System.out.print("Invalid details! Enter the number of Part-Time Staff members: ");
                        while (n <= 0) {
			    System.out.print("Invalid details! Enter the number of Part-Time Staff members: ");
                            n = Integer.parseInt(br.readLine());
                        }
        
                        staff = new Staff[n];
        
                        for (int i = 0; i < n; i++) {
                            System.out.println("Enter details for Part-Time Staff member " + (i + 1) + ":");
        
                            System.out.print(" Employee Name: ");
                            String name = br.readLine();
                            while (name.length() == 0) {
                                System.out.print("Name can not be empty! Try again: ");
                                name = br.readLine();
                            }
        
                            System.out.print("Employee Address: ");
                            String address = br.readLine();
                            while (address.length() == 0) {
                                System.out.print("Address can not be empty! Try again: ");
                                address = br.readLine();
                            }
        
                            System.out.print("Number of Hours: ");
                            int numberOfHours = Integer.parseInt(br.readLine());
                            while (numberOfHours <= 0 ) {
                                System.out.print("Invalid details! Enter Number of Hours: ");
                                numberOfHours = Integer.parseInt(br.readLine());
                            }
        
                            System.out.print("Rate per Hour: ");
                            double ratePerHour = Double.parseDouble(br.readLine());
                            while(ratePerHour<=0)
                           {
                                System.out.print("invalid details! enter Rate per Hour");
                                ratePerHour = Double.parseDouble(br.readLine());
                           }

                           staff[i] = new PartTimeStaff(name, address, numberOfHours, ratePerHour);

                          }

                          //display
                        System.out.println("\nPart-Time Staff Details:");
                        for (int i = 0; i < n; i++) {
                            staff[i].displayDetails();
                            System.out.println();
                        }
                        break;

                        case 3:
                             break;

                }

            }while(choice!=3);

    }
}
