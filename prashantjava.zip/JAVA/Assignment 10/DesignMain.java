import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class design extends JFrame implements ActionListener
{
	JLabel boxes[] = new JLabel[16];
	JButton b1, b2, b3, b4;
	int currentPos = 13;
	
	Color blackColor = Color.BLACK;
	Color whiteColor = Color.WHITE;
	Color temp;
	
	design()
	{
		setSize(700,700);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		setLayout(new GridLayout(5,4));
		
		for(int i = 1;i<=16;i++)
		{
			boxes[i-1] = new JLabel();
				if(i%2 == 0)
				{
					boxes[i-1].setBackground(whiteColor);
					boxes[i-1].setOpaque(true);
				}
				else
				{
					boxes[i-1].setBackground(blackColor);
					//boxes[i-1].setBackground(whiteColor);
					boxes[i-1].setOpaque(true);
				}
				if(i%4 == 0)
				{
					temp = blackColor;
					blackColor = whiteColor;
					whiteColor = temp;
				}
			add(boxes[i-1]);
		}
		
		b1 = new JButton("Up");
		b2 = new JButton("Down");
		b3 = new JButton("Left");
		b4 = new JButton("Right");
		
		add(b1);
		add(b2);
		add(b3);
		add(b4);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		
		changePos();
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource() == b1)
		{
			if((currentPos-4) >= 0)
			{
				boxes[currentPos].setText("");
				currentPos -= 4;
				changePos();
			}
			else
				JOptionPane.showMessageDialog(b1,"Up limit exceeded","Alert",JOptionPane.ERROR_MESSAGE);
		}
		else if(ae.getSource() == b2)
		{
			if((currentPos+4) < 16)
			{
				boxes[currentPos].setText("");
				currentPos += 4;
				changePos();
			}
			else
				JOptionPane.showMessageDialog(b2,"Down limit exceeded","Alert",JOptionPane.ERROR_MESSAGE);
		}
		else if(ae.getSource() == b4)
		{
			if((currentPos+1) < 16)
			{
				boxes[currentPos].setText("");
				currentPos += 1;
				if((currentPos) == 4 || (currentPos) == 8 || (currentPos) == 12)
				{
					currentPos -= 1;
					changePos();
					JOptionPane.showMessageDialog(b4,"Right limit exceeded","Alert",JOptionPane.ERROR_MESSAGE);
				}
				else
					changePos();
			}
			else
			{
				changePos();
				JOptionPane.showMessageDialog(b4,"Right limit exceed","Alert",JOptionPane.ERROR_MESSAGE);
			}
		}
		else
		{
			if((currentPos-1) >= 0)
			{
				boxes[currentPos].setText("");
				currentPos -= 1;
				if((currentPos) == 3 || (currentPos) == 7 || (currentPos) == 11)
				{
					currentPos += 1;
					changePos();
					JOptionPane.showMessageDialog(b3,"Left limit exceeded","Alert",JOptionPane.ERROR_MESSAGE);
				}
				else
					changePos();
			}
			else
			{
				changePos();
				JOptionPane.showMessageDialog(b3,"Left limit exceed","Alert",JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	void changePos()
	{
		boxes[currentPos].setText("*");
		boxes[currentPos].setFont(new Font("Curior",Font.BOLD,25));
		boxes[currentPos].setHorizontalAlignment(JLabel.CENTER);
		
		if(boxes[currentPos].getBackground() == Color.BLACK)
		{
			boxes[currentPos].setForeground(Color.WHITE);
		}
	}
}

public class DesignMain
{
	public static void main(String args[])
	{
		new design();
	}
}
