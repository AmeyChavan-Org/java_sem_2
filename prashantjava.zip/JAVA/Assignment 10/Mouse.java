import java.applet.*;
import java.awt.*;
import java.awt.event.*;

/* <APPLET CODE="Mouse" WIDTH="400" HEIGHT="400">
   </APPLET>
*/
public class Mouse extends Applet
{

	public void init() 
	{
  		addMouseListener(new MyMouseAdapter());
  		addMouseMotionListener(new MyMouseMotionAdapter());
	}	

	public class MyMouseAdapter extends MouseAdapter
	{

  	public void mouseClicked(MouseEvent me) 
	{
  		showStatus("Mouse clicked  ");
 	}
}

public class MyMouseMotionAdapter extends MouseMotionAdapter
{
 

 public void mouseMoved(MouseEvent me) 
{
 
  showStatus("Mouse moved "+ me.getX() + ", " + me.getY());

 }

 public void mouseDragged(MouseEvent me) 
{

  showStatus("Mouse dragged ");
  
 }
}
}
