package MScCAI;
import java.io.*;
public class MScCAIMarks
{
public int SemItotal,SemIItotal;

public void AcceptMScCAIMarks()throws IOException 
{
	 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));//input accesept from user throw keyboad using bufferedReader class 
	  System.out.println("Enter Msc CAI sem1 Marks Out Of 100 = ");
	    while(true)
	    {
	     SemItotal=Integer.parseInt(br.readLine());
	     if(SemItotal>=0&&SemItotal<=100)
	        break;
	     else
	        System.out.println("Please Enter The Valid Marks");
	     }
	    
	    System.out.println("Enter Msc CAI sem2 Marks Out Of 100 = ");
	    while(true)
	    {
	     SemIItotal=Integer.parseInt(br.readLine());
	     if(SemIItotal>=0&&SemIItotal<=100)
	        break;
	     else
	        System.out.println("Please Enter The Valid Marks");
	
	    }
	 }

}
