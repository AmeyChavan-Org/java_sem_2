package MScCAII;
import java.io.*;
public class MScCAIIMarks
{
public int SemItotal,SemIItotal;
public void AcceptMScCAIMarks2()throws IOException 
{
 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));//input accesept from user throw keyboad using bufferedReader class 
  System.out.println("Enter Msc CAII sem1 Marks Out Of 100 = ");
    while(true)
    {
     SemItotal=Integer.parseInt(br.readLine());
     if(SemItotal>=0&&SemItotal<=100)
        break;
     else
        System.out.println("Please Enter The Valid Marks");
     }
    
    System.out.println("Enter Msc CAII sem2 Marks Out Of 100 = ");
    while(true)
    {
     SemIItotal=Integer.parseInt(br.readLine());
     if(SemIItotal>=0&&SemIItotal<=100)
        break;
     else
        System.out.println("Please Enter The Valid Marks");
     }
   }
}
