package Numoperation;
public class Prime
{
	int num,flag=0;
	public void isPrime(int num)
	{
		
		if(num<=0 || num==1)
		{
			System.out.println(num+" not a prime number");
		}
		else
		{
			for(int i=2;i<num;i++)
			{
				if(num%i==0)
				{
					System.out.println(num+" not a prime number");
					flag=1;
					break;
				}
			}
			if(flag==0)
			{
				System.out.println(num+" is a prime number");
			}
		}
	
	}
}
