package Numoperation;
public class Perfect
{
	public void isPerfect(int num)
	{
		
		if(num==0)
		{
			System.out.println(num+" is not a perfect number");
		}
		else
		{
			int sum=0;
			for(int i=1;i<num;i++)
			{
				if(num%i==0)
				{
					sum=sum+i;
				}
			}
			if(sum==num)
			{
				System.out.println(num+" is a perfect number");
			}
			else
			{
				System.out.println(num+" is not a perfect number");	
			}
		}
		
	}
}


