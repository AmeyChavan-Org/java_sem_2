package Numoperation;
public class Armstrong
{
	int rem;	
	public void isArmstrong(int num)
	
	{
		int sum=0;
		int temp=num;
		int count=0;
		if(num>=0)
		{
			while(temp>0)
			{
				temp=temp/10;
				count++;
			}
			temp=num;
			while(temp>0)
			{
				int mul=1;
				int digit=temp%10;
				for(int i=0;i<count;i++)
					mul=digit*mul;
					sum=sum+mul;
					temp=temp/10;
			}			
			if(num==sum)
			{
				System.out.println(num+" is Armstrong number");
			}	
		        else
			{
				System.out.println(num+" is not armstrong number");
			}		
				
			
		}
	        else 
		{
			System.out.println(num+" is not armstrong number");
		}
		
	}
		
}

