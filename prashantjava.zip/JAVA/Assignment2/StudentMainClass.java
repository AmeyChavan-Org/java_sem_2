import java.io.*;
import MScCAI.*;
import MScCAII.*;
class Student
{
	 String name;
	 static int roll=0;
	 int r;
	 int total=0;				//instance variable
	 String grade;
	 int MScCAIMarks,MScCAIIMarks;
	
	public Student(String name)//parameterized constructor
	{
	  this.name=name;
	  this.roll=roll+1;
	  r=roll;
  
	}
	public void display()throws IOException
	{
	
	  MScCAIMarks obj1 = new MScCAIMarks();
	  obj1.AcceptMScCAIMarks();
 
	  MScCAIIMarks obj2 = new MScCAIIMarks();

 	  obj2.AcceptMScCAIMarks2();
      
	MScCAIMarks=obj1.SemItotal+obj1.SemIItotal;
	 
	MScCAIIMarks=obj2.SemItotal+obj2.SemIItotal;



	int total= MScCAIMarks + MScCAIIMarks;


	float per=(total)/4;
	if(per>70)
	   grade="A";
	else if(per>=60 && per<=70)
	   grade="B";
	else if(per>=50 && per<=60)
	   grade="C";
	else if(per>=40 && per<=50)
	   grade="Pass";
	else
	   grade="Fail";

 
	//System.out.println("****************************First Year Result**********************************");
	System.out.println("Result\n");	
	System.out.println("Roll number= "+r+"\t");
	System.out.println("Student name= "+name+"\t\n");

	//System.out.println("Student name =);
 		
	System.out.println("Class\t\t Semester\tmarks\t\n");
	System.out.println("MSCCAI\t\tSem_I\t\t"+obj1.SemItotal+"\n");
	System.out.println("MSCCAI\t\tSem_II\t\t"+obj1.SemIItotal+"\n");
	//System.out.println("Total Marks Of MSCCAI\t   Sem_I  Are= "+(obj1.SemItotal+obj1.SemIItotal));
	//System.out.println("***************************Second Year Result**********************************");
	System.out.println("MSCCAII\t\tSem_I\t\t"+obj2.SemItotal+"\n");
	System.out.println("MSCCAII\t\tSem_II\t\t"+obj2.SemIItotal+"\n");
	//System.out.println("Total Marks Of MSCCAI\t Sem_II  Are= "+(obj2.SemItotal+obj2.SemIItotal));
	

	System.out.println("Student Percentage Are = "+per);
	System.out.println("Student Grade Are = "+grade);
	System.out.println("*******************************************************************************");
      }
}
class StudentMainClass
{
public static void main(String args[])throws IOException
{  
  int n;
  String name;
  
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));//input accesept from user throw keyboad using bufferedReader class 
   
  do{
     System.out.println("Enter How Many student you want..?");
     n=Integer.parseInt(br.readLine());
    }while(n<=0);

    Student s[]=new Student[n];//create array of student and passing n values to the student array
  
  for(int i=0;i<n;i++)
   {
     System.out.println("Roll Number= "+(Student.roll+1));
     do{
        System.out.println("Enter The Name Of The Student  = ");
        name=br.readLine();
       }while(name.length()==0);
      
      
      s[i]=new Student(name);
     s[i].display();
    
   
     }
   }
}
