import java.io.*;
import Numoperation.*;

class NumOperationMain
{
	public static void main(String[] args)throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int n;
		System.out.println("Please Enter a Number Which You Want:");
		while(true)
		{
			n=Integer.parseInt(br.readLine());
			if(n>=0)
				break;
			else
				System.out.println("Invalid Input");	
				System.out.println("please Re-enter the Valid number:");
			
		}
	
		Prime pr=new Prime();
		Perfect pf=new Perfect();
		Armstrong ar=new Armstrong();

		pr.isPrime(n);
		pf.isPerfect(n);
		ar.isArmstrong(n);
		
	}
}
