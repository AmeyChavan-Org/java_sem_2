import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class Conversion extends JFrame
{
	JButton b1,b2;
	JLabel l1,l2,l3,l4,l5,l6,l7;
	JTextField t1;

	Conversion()	
	{
		JFrame f = new JFrame("Number Conversion");
		f.setSize(480,200);
		f.setLayout(new GridLayout(5,2));

		JLabel l1 = new JLabel("Decimal Number");
		JTextField t1 = new JTextField(10);
		t1.setEditable(true);
		
		JLabel l2 = new JLabel("Binary Number");
		JLabel l3 = new JLabel("");
		JLabel l4 = new JLabel("Result in Binary");	
		
		JLabel l5 = new JLabel("Ocatl Number");
		JLabel l6 = new JLabel("");
		JLabel l7 = new JLabel("Result in Octal");
		
		JLabel l8 = new JLabel("Hexadecimal Number");
		JLabel l9 = new JLabel("");
		JLabel l10 = new JLabel("Result in Hexadecimal");
		
		JButton b1 = new JButton("Convert");
		JButton b2 = new JButton("Exit");
		
		f.add(l1);
		f.add(t1);
		f.add(l2);
		f.add(l4);
		f.add(l5);
		f.add(l7);
		f.add(l8);
		f.add(l10);
		f.add(b1);
		f.add(b2);
		f.setVisible(true);
		f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);	
	}
	public static void main(String args[])
	{
		new Conversion();		
	}
}
