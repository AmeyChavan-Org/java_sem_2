import java.awt.*;
import java.applet.*;

/*<applet code = "applet" width=500 height=500>
</applet>*/


public class applet extends Applet
{
	String msg = null;
	String msg1 = null;
	
	public void init()
	{
		setBackground(Color.blue);
		msg = "Inside Init Method";
	}
	
	public void start()
	{
		msg1 = "Inside Start Method";
	}
	
	public void paint(Graphics g)
	{
		g.setColor(Color.yellow);
		g.drawString("First Applet Program",150,85);
		g.drawString("Wel-Come",305,85);
		g.drawString(msg,20,20);
		g.drawString(msg1,60,60);
		g.drawString("Inside Paint Method",100,100);
	}
}
