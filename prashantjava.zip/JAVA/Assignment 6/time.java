import java.awt.*;
import java.applet.*;
import java.util.*;
import java.text.*;

/*<applet code = "time" width=600 height=600>
</applet>*/

public class time extends Applet
{
	public void paint(Graphics g)
	{
		Calendar cal = Calendar.getInstance();
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		int hour = cal.get(Calendar.HOUR);
		int minute = cal.get(Calendar.MINUTE);
		int second = cal.get(Calendar.SECOND);
		String time = ""+hour+":"+minute+":"+second;
		g.drawString(time,20,20);
		String strDate = sdf.format(d);
		g.drawString(strDate,20,40);
		
		if(hour>=0 && hour<12)
			showStatus("Good Morning!!");
		else if(hour>=12 && hour<17)
			showStatus("Good Afternoon");
		else if(hour>=17 && hour<20)
			showStatus("Good Evening");
		else
			showStatus("Good night");
	}
}
