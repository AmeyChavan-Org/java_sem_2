import java.awt.*;
import java.applet.*;
import java.util.*;

/*<applet code = "vowels" width=600 height=600>
<param name = "Message" value = " Fergusson">
</applet>
*/

public class vowels extends Applet
{
	String demomsg = null;
	public void init()
	{
		demomsg = getParameter("Message");
	}
	
	public void paint(Graphics g)
	{
		String msg = "";
		boolean flag = false;
		g.drawString(demomsg,50,25);
		for(int i = 0; i<demomsg.length(); i++)
		{
			if(demomsg.charAt(i) == 'a' || demomsg.charAt(i) == 'e' || demomsg.charAt(i) == 'i' || demomsg.charAt(i) == 'o' || demomsg.charAt(i) == 'u' || demomsg.charAt(i) == 'A' || demomsg.charAt(i) == 'E' || demomsg.charAt(i) == 'I' || demomsg.charAt(i) == 'O' || demomsg.charAt(i) == 'U')
			{
				if(flag = false)
				{
					msg = ""+demomsg.charAt(i);
					flag=true;
				}
				else
					msg+=" "+demomsg.charAt(i);
			}
				showStatus("Vowels in string are :"+msg);
		}
	}
}
