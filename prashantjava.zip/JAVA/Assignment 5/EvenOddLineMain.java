import java.io.*;

public class EvenOddLineMain {
    public static void main(String kru[]) {
        if (kru.length == 0) {
            System.out.println("Invalid Argument:");
            System.exit(0);
        }
        String inputFile = kru[0];

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile));
                BufferedWriter even = new BufferedWriter(new FileWriter("even.txt"));
                BufferedWriter odd = new BufferedWriter(new FileWriter("odd.txt"))) {
            String line;
            int nol = 1;
            while ((line = br.readLine()) != null) {
                if (nol % 2 == 0) {
                    even.write(line);
                    even.newLine();
                } else {
                    odd.write(line);
                    odd.newLine();
                }
                nol++;
            }
        } catch (IOException m) {
            m.printStackTrace();
        }
    }

}
