import java.io.*;
import java.io.FileReader;

public class FileNoLineMain {
    public static void main(String args[]) {
        if (args.length == 0) {
            System.out.println("Invalid Argument:");
           System.exit(0);
        }
	else
	{
        String fname = args[0];

        try {
            String fileName;
            BufferedReader br = new BufferedReader(new FileReader(fname));
            int nol = 0, noc = 0, now = 0;

            String line;

            while (((line = br.readLine()) != null)) {
                nol++;
                noc += line.length();
                String[] w = line.trim().split("\\s+");
                now += w.length;

            }
            br.close();
            System.out.println("Number of Lines:" + nol);
            System.out.println("Number of Characters:" + (noc+nol));
            System.out.println("Number of Words:" + now);
        } catch (Exception e1) {
            System.out.println("Error Occured" + e1.getMessage());
        }
    }
}
