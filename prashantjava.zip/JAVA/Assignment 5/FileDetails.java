import java.io.*;
import java.io.File;

public class FileDetails {
    public static void main(String args[]) throws IOException {
        if (args.length == 0) {
            System.out.println("Please enter valid input on command line.");
            System.exit(0);
        }
        File f = new File(args[0]);// It assumes path of directory or file in the file system
        if (f.isFile()) {
            System.out.println("A file Information");

            System.out.println("file Name:" + f.getName());

            System.out.println("Path of file:" + f.getAbsolutePath());
            System.out.println("Relative Path:" + f.getPath());
            System.out.println("Size of File or directory: " + f.length() + " bytes");
            System.out.println("Is File Readable?" + f.canRead());
            System.out.println("Is File Writable?" + f.canWrite());
            System.out.println("Is File Executable?" + f.canExecute());
            System.out.println("Last Modified:" + f.lastModified());
        } else if (f.isDirectory()) {
            File[] fp = f.listFiles();
            if (fp == null || fp.length == 0) {
                System.out.println("The Directory is empty");
                return;
            }
            int fcount = 0;
            System.out.println("Content Of Specified Directory:");
            for (int i = 0; i < fp.length; i++) {
                File fp1 = fp[i];// this type allocation is known as object assignment
                System.out.println(fp1.getName());
                if (fp1.isFile()) {
                    fcount++;
                }
            }
            System.out.println("Number of files in directory are:" + fcount);
            System.out.println("Names of all Files in Directory having extension .txt:");
            for (int i = 0; i < fp.length; i++) {
                File fp1 = fp[i];
                if (fp1.isFile() && fp1.getName().endsWith(".txt")) {
                    System.out.println(fp1.getName());
                }
            }

        } else {
            System.out.println("Given Path does not exist");
        }

    }
}
