import java.io.*;
class Student
{
	static int roll=0;
	String name;
	float percentage;
	int r;
	
      	//default constructor
	Student()
	{
	}
	
	//parameterized constructor
	Student(String name,float percentage)
	{
	  
	  this.name=name;
	  this.percentage=percentage;
	  this.roll=roll+1;
	  r=roll;
          
	}

	static void sortStudent(Student s[],int n)  //student marks sorting with respect to pecentage 
	{
	 for(int i=0;i<n;i++)
	 {
	  for(int j=0;j<n-i-1;j++)
	  {
           if(s[j].percentage<s[j+1].percentage)
	   {
 	     Student temp=new Student();
	     temp=s[j];
	     s[j]=s[j+1];
	     s[j+1]=temp;
	   }
	  }
         }
	}
	public String toString()
	{
		return "Roll no :"+r+ " name :"+name+ " percentage :"+percentage;
	}
}//end of class

class StudentMain
{

	public static void main(String args[])throws IOException
	{
	 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));//input accesept from user throw keyboad using bufferedReader class 0
	 
	 String name;
	 float percentage;

	 System.out.println("Enter how many students:");
	 int n;  //accepting the user input
	 while(true)
	 {
		n=Integer.parseInt(br.readLine());
		if(n>0)
	 	   break;
		else
		   System.out.println("Invalid input");
		   System.out.println("Re-enter how many students you want:");
	 }	 
	 Student[] s=new Student[n];
	 for(int i=0;i<n;i++)
	 {
	   System.out.println("Enter roll:"+(Student.roll+1));
	 do
	 {
	   System.out.println("Enter name:");
	   name=br.readLine();
	 }while(name.length()==0);
	   System.out.println("Enter percentage :");
	   while(true)
	   { 
		percentage=Float.parseFloat(br.readLine());
	        if(percentage >=0 && percentage<=100)
		  break;
		else
		 System.out.println("Percentage should not be negative or equal to zero(0)");
		 System.out.println("Re-enter Percentage:");
	   }
	   s[i]=new Student(name,percentage);
	 }
	Student.sortStudent(s,n);// sort method calling 
	for(int i=0;i<n;i++)
	{
	 System.out.println(s[i]);
	}
	} //end of main
} //end of class
