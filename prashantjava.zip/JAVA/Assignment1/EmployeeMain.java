import java.io.*;
class employee
{
   String name;
   String position;
   double salary;
   static int count=0;

  public employee()  //default constructor
  {
    this.name="";
    this.position="";
    this.salary=0;
    count++;
  }

  public employee(String name,String position,double salary) //parameterized constructor
  {
    this.name=name;
    this.position=position;
    this.salary=salary;
    count++;
  }

  
  //use tostring method (method called)
  public String toString()
  {
    return"\t Name Of The Employee is:"+name+"\t Position :"+position+"\t Salary :"+salary;
  }
 
//getcount method for object count (method called)
  public static int getCount()
  {
   System.out.println("Object Count:"+count);
   return count;
  }
} //end of class

class EmployeeMain
{
   public static void main(String[] args)throws IOException
   {
     BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); //input accesept from user throw keyboad using bufferedReader class 
     
     {
     	System.out.println("How many employee you want:");
     	int n;
	while(true)
	{
	   n=Integer.parseInt(br.readLine());
	   if(n>0)
		break;
	   else
		System.out.println("Invalid Input");
		System.out.println("Re-enter no of employee you want:");	   
	}
     	employee[] e1=new employee[n];
	String position;
	double salary;
	String name;
  
     
        for(int i=1;i<=n;i++)
        {
 	  do
	  {
		System.out.println("Enter the name of employee:");
          	name=br.readLine();
	  }while(name.length()==0);
	  do
	  {
		System.out.println("Enter the position of Employee:");
          	position=br.readLine();
	  }while(position.length()==0);  
         
          
          System.out.println("Enter the salary of employee:");
          while(true)
          {  
            salary=Double.parseDouble(br.readLine());
            if(salary>0)
                   break;
            else
                   System.out.println("Invalid input");
                   System.out.println("Re-Enter Salary : ");
          }

          employee e=new employee(name,position,salary);
          System.out.println(e.getCount());//(method calling)
          System.out.println(e.toString());//(method calling)
        }
     }
   }  //end of class
}   //end of main
