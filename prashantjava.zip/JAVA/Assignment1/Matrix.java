import java.io.*;

class Matrix
{
	public static int[][] add(int[][] m1,int[][] m2)// add method called
	{
	  int row=m1.length;
	  int col=m1[0].length;
	  int res[][]=new int[row][col];
	  for(int i=0;i<row;i++)
	  {
	    for(int j=0;j<col;j++)
	    {
		res[i][j]=m1[i][j] + m2[i][j];
	    }
	    
	  }
	 return res;
	}//end of class
	public static void main(String[] args)throws IOException
  	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); //input accesept from user throw keyboad using bufferedReader class 
		int row,col,i,j,row1,col1;
	
		System.out.println("Enter the no of rows:");
	        while(true)
	        {
		  row=Integer.parseInt(br.readLine());
	          if(row>0)
		     break;
		  else
		     System.out.println("Re-enter the row");	
		}

		//row = Integer.parseInt(br.readLine());

		System.out.println("Enter the no of columns:");
		while(true)	     	
		{
			col = Integer.parseInt(br.readLine());
			if(col>0)
		           break;
		        else
		           System.out.println("Re-enter the col");	
		}
  		

		int m1[][]=new int[row][col];
		System.out.println("Enter the no of rows:");
		while(true)
	        {
		  row1=Integer.parseInt(br.readLine());
	          if(row1>0)
		     break;
		  else
		     System.out.println("Re-enter the row");	
		}
		
		System.out.println("Enter the no of column:");

		while(true)	     	
		{
			col1 = Integer.parseInt(br.readLine());
			if(col1>0)
		           break;
		        else
		           System.out.println("Re-enter the col");	
		}
		int m2[][]=new int[row1][col1];
		if(row==row1 && col==col1)
		{

		System.out.println("Enter the elements of matrix 1");
		 for(i=0;i<row;i++)
	 	 {
	   	    for(j=0;j<col;j++)
		    {
			m1[i][j]=Integer.parseInt(br.readLine());
		    }
		    System.out.println();
		}
		
		System.out.println("Enter the elements of matrix 2:");
		for(i=0;i<row;i++)
		{
		   for(j=0;j<col;j++)
		   {
			m2[i][j]=Integer.parseInt(br.readLine());
		   }
		   System.out.println();
		}
		
		int res[][]=add(m1,m2);//add method calling 
		System.out.println("The addition of matrix is:");
		for(i=0;i<row;i++)
		{
		   for(j=0;j<col;j++)
		   {
		      System.out.print(res[i][j]+" ");	
		   }
		   System.out.println();
		}
		}
		else
		{
			System.out.println("Dimensions not match");
		}
	}
}

	
