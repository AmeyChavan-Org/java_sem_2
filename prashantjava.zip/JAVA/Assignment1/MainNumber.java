import java.io.*;
class Number
{
	private int data;
	
	Number()
	{
          data=0;
	}
	Number(int data)
	{
	 this.data=data;
	}
	void check()
	{
	  if(data!=0)
	  {
  	    Evenodd();// Evenodd Method calling 
	    Positivity();// positivity Method calling 
       	  }
	  else
	    System.out.println("Enter number = "+data+" is zero");
	}
        void Evenodd()// Evenodd Method called 
	{
	if(data%2==0)
	  {
           System.out.println("Enter number = "+data+" is even");
	  }
	  else
	   System.out.println("Enter number = "+data+" is odd");
	} 
	 
	void Positivity()// positivity Method called 
	{
	  if(data>0)
	  {
	    System.out.println("Enter number = "+data+" is positive");
          }
	  else
	  
 	   System.out.println("Enter number = "+data+" is negative");
          }
}

class MainNumber
{
	public static void main(String args[])throws IOException
	{
	  if(args.length==0)// it check the length of the args[] array
	  {
		System.out.println("No arguments is supplied");
	  }
	  else
	  {
	  	int data= Integer.parseInt(args[0]);
	  	Number ob = new Number(data);
	        ob.check();
	  }
	}
}
